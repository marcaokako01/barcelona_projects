param(
  [string]$ResourceGroup = "GrupoFinal",
  [string]$AppName = "barcelona-ai-vapi-web",
  [string]$ZipName = "app.zip",
  [int]$MaxRetries = 5
)

$ErrorActionPreference = "Stop"

function Write-Info($msg) { Write-Host "[INFO] $msg" -ForegroundColor Cyan }
function Write-Warn($msg) { Write-Host "[WARN] $msg" -ForegroundColor Yellow }
function Write-Err ($msg) { Write-Host "[ERR ] $msg" -ForegroundColor Red }

function Ensure-AzCli {
  if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    throw "Azure CLI (az) não encontrado no PATH. Instale o Azure CLI e reabra o terminal."
  }
}

function Ensure-AzLogin {
  try {
    $null = az account show 2>$null
    Write-Info "Sessão Azure OK."
  } catch {
    Write-Warn "Sem sessão Azure. Abrindo login..."
    az login | Out-Null
  }
}

function Clean-Pycaches {
  Write-Info "Removendo __pycache__ e *.pyc (se existirem)..."
  Get-ChildItem -Recurse -Force -Directory -Filter "__pycache__" -ErrorAction SilentlyContinue |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue

  Get-ChildItem -Recurse -Force -File -Filter "*.pyc" -ErrorAction SilentlyContinue |
    Remove-Item -Force -ErrorAction SilentlyContinue
}

function Build-Zip {
  param([string]$ZipPath)

  if (Test-Path $ZipPath) {
    Remove-Item $ZipPath -Force
  }

  # Seleciona somente itens que devem entrar no zip
  $items = Get-ChildItem -Force | Where-Object {
    $_.Name -notin @(
      "env","venv","antenv",".git",".vscode",".github",
      $ZipName
    ) -and
    $_.Name -notlike ".env*" -and
    $_.Name -notlike "*.pem" -and
    $_.Name -notlike "*.key"
  }

  Write-Info "Criando zip: $ZipPath"
  Compress-Archive -Path $items.FullName -DestinationPath $ZipPath -Force

  Write-Info "Validando conteúdo do zip (primeiras 30 entradas)..."
  tar -tf $ZipPath | Select-Object -First 30 | ForEach-Object { Write-Host "  $_" }

  # sanity checks
  $zipList = tar -tf $ZipPath
  if ($zipList -notmatch "^requirements\.txt$") {
    Write-Warn "requirements.txt não apareceu no zip (na raiz). Verifique se você está na pasta correta do projeto."
  }
  if ($zipList -notmatch "^app/main\.py$") {
    Write-Warn "app/main.py não apareceu no zip. Verifique estrutura do projeto."
  }
}

function Deploy-ZipWithRetry {
  param(
    [string]$RG,
    [string]$Name,
    [string]$ZipPath,
    [int]$Retries
  )

  for ($i=1; $i -le $Retries; $i++) {
    try {
      Write-Info "Deploy attempt $i/$Retries..."
      # Evita erro por deploy colado com restart
      Start-Sleep -Seconds (3 * $i)

      az webapp deploy `
        --resource-group $RG `
        --name $Name `
        --src-path $ZipPath `
        --type zip | Out-Null

      Write-Info "Deploy concluído com sucesso."
      return
    } catch {
      $msg = $_.Exception.Message
      Write-Warn "Falha no deploy: $msg"

      # tenta pegar info do latest deployment (sem quebrar o script)
      try {
        Write-Info "Buscando status do último deployment..."
        az webapp log deployment show -g $RG -n $Name 2>$null | Out-Host
      } catch { }

      if ($i -eq $Retries) { throw }
      Write-Warn "Aguardando para tentar novamente..."
      Start-Sleep -Seconds (10 * $i)
    }
  }
}

function Set-AppConfig {
  param([string]$RG, [string]$Name)

  Write-Info "Aplicando App Settings..."
  az webapp config appsettings set -g $RG -n $Name --settings `
    SCM_DO_BUILD_DURING_DEPLOYMENT=1 `
    WEBSITES_PORT=8000 | Out-Null

  # Startup command (Linux App Service)
  $startup = "gunicorn -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000 app.main:app"
  Write-Info "Definindo Startup Command..."
  az webapp config set -g $RG -n $Name --startup-file $startup | Out-Null
}

function Restart-App {
  param([string]$RG, [string]$Name)
  Write-Info "Reiniciando app..."
  az webapp restart -g $RG -n $Name | Out-Null
}

# ===================== main =====================
Write-Info "Iniciando deploy para: $AppName (RG: $ResourceGroup)"
Ensure-AzCli
Ensure-AzLogin

Clean-Pycaches

$zipPath = Join-Path (Get-Location) $ZipName
Build-Zip -ZipPath $zipPath

# Deploy primeiro; só depois mexe em config para evitar SCM restart no meio
Deploy-ZipWithRetry -RG $ResourceGroup -Name $AppName -ZipPath $zipPath -Retries $MaxRetries

Set-AppConfig -RG $ResourceGroup -Name $AppName
Restart-App -RG $ResourceGroup -Name $AppName

Write-Info "Pronto! Agora valide em / e /docs."
