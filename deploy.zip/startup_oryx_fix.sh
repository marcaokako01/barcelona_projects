cat > /home/site/wwwroot/startup_oryx_fix.sh <<'EOF'
#!/bin/bash
set -e
cd /home/site/wwwroot

# Se app/ sumir em algum restart, reextrai do output.tar.gz
if [ ! -d "app" ] && [ -f "output.tar.gz" ]; then
  tar -xzf output.tar.gz -C /home/site/wwwroot ./app ./requirements.txt 2>/dev/null || \
  tar -xzf output.tar.gz -C /home/site/wwwroot
fi

exec gunicorn -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000 app.main:app
EOF

chmod +x /home/site/wwwroot/startup_oryx_fix.sh
