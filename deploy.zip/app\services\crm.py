class CRMService:
    def save_interaction(self, call_id, data):
        pass
    
    def notify_closer(self, lead_data):
        print(f"ALERTA FERNANDA ARO: Novo lead quente! {lead_data}")
